class Divergence {
  public static boolean f() {
    return f();
  }

  static boolean bool = f();

  public static void main(String[] args) {}
}
