#!/usr/bin/env runghc

data False

data Rec a = Rec { rec :: Rec a -> a }

false :: False
false = rec (Rec (\a -> rec a a))
            (Rec (\a -> rec a a))

main = return ()
